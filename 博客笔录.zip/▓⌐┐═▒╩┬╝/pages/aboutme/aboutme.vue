<template>
	<view>
		<view class="user-part">
			<view class="title-part">
				<text class="title">关于我们</text>
			</view>
			<view class="text-part">
				<text >
					欢迎来到我们的小程序！这里，我们致力于为用户提供便捷、高效且富有创意的服务体验。通过我们的小程序，您可以轻松享受到各种功能与服务，满足您的日常需求。
					
					我们的使命
					
					我们的使命是成为您日常生活中的得力助手，通过我们的小程序，让您的生活更加便捷、高效。我们不断创新，努力提升用户体验，希望为每一位用户带来惊喜与满足。
					
					我们的团队
					
					我们拥有一支专业、富有激情的团队，他们来自不同领域，拥有丰富的经验和技术能力。他们秉持着用户至上的原则，竭诚为用户提供最优质的服务。
					
					我们的服务
					
					我们的小程序提供了多种功能与服务，包括但不限于信息查询、在线购物、社交互动等。我们将不断优化服务内容，满足用户日益增长的需求。
					
					我们的承诺
					
					我们承诺尊重并保护用户的隐私权益，严格遵守相关法律法规。我们将采取各种措施，确保用户数据的安全与保密。
					
					联系我们
					
					如果您在使用我们的小程序过程中遇到任何问题或建议，欢迎随时与我们联系。我们将竭诚为您解答疑问，听取您的宝贵意见，以便更好地为您服务。
					
					感谢您的信任与支持，我们期待与您携手共创美好未来！
				</text>
			</view>
		</view>	
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			
		}
	}
</script>

<style>
	.title-part{
		display: flex;
		justify-content: center;
	}
	.title{
		
		color: black;
		font-size: 50rpx;
		font-weight: 1000;
		
	}
	.text-part{
		margin-top: 3%;
		margin-left: 2%;
		margin-right: 2%;
		margin-bottom: 2%;
	}
</style>
